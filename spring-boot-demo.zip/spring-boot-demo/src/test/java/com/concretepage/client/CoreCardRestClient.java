package com.concretepage.client;

import java.net.URI;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import com.concretepage.entity.Article;


public class CoreCardRestClient {
	
	
    public void sendSMSGlobal() {
    	
	
    	Date date =new Date();
    	
    	String formattedDate = new SimpleDateFormat("dd-MM-YYYY HH:mm:ss").format(date);
    	
    	String input = "{\"CCPushNotification\": { \"requestData\": {\"MobileNumber\":\"9652458877\",\"UniqueID\":\"MDWL174930014989611\",\"message\":\"The balance is 50 SGD\",\"endpoint\":\"SMSGLOBAL\",\"client\" :\"LMN\",\"RequestDateTime\":"+'"'+formattedDate+'"'+"}}}";
    	 HttpHeaders headers = new HttpHeaders();
    	headers.setContentType(MediaType.APPLICATION_JSON);
    	RestTemplate restTemplate = new RestTemplate();
	    String url = "http://localhost:8080/WireConnectNotification/CCPushNotification";
	    HttpEntity<String> requestEntity = null;
        requestEntity=new HttpEntity<String>(input, headers);
        //URI uri = restTemplate.postForLocation(url, requestEntity);
        
       restTemplate.postForEntity(url, requestEntity, null);
        
       //System.out.println(uri.getPath());
        
      
    }
    
    public void sendMach() {
    	
    	Date date =new Date();
    		
    		String formattedDate = new SimpleDateFormat("dd-MM-YYYY HH:mm:ss").format(date);
        	
        	String input = "{\"CCPushNotification\": { \"requestData\": {\"MobileNumber\":\"9652458877\",\"UniqueID\":\"MDWL174930014989611\",\"message\":\"The balance is 100 SGD\",\"endpoint\":\"SMSMach\",\"client\" :\"JPPL\",\"RequestDateTime\":"+'"'+formattedDate+'"'+"}}}";
        	
        	String payload = " { \"StatementsInformation\" : { \"requestData\" : { \"ProxyNumber\" :\" 9999999999 \",\"StatementDate\" : \"23-dec-2017\"}}}"; 
        	 HttpHeaders headers = new HttpHeaders();
        	headers.setContentType(MediaType.APPLICATION_JSON);
        	RestTemplate restTemplate = new RestTemplate();
    	    String url = "http://localhost:8080/WireConnectNotification/CCPushNotification";
    	    HttpEntity<String> requestEntity = null;
            requestEntity=new HttpEntity<String>(payload, headers);
            //URI uri = restTemplate.postForLocation(url, requestEntity);
            
           restTemplate.postForEntity(url, requestEntity, null);
            
           //System.out.println(uri.getPath());
            
          
        }
    
 public void sendTechStudio() {
    	
    	Date date =new Date();
    		
    		String formattedDate = new SimpleDateFormat("dd-mm-yyyy HH:mm:ss").format(date);
        	
        	String input = "{\"CCPushNotification\": { \"requestData\": {\"MobileNumber\":\"9652458877\",\"UniqueID\":\"MDWL174930014989611\",\"message\":\"The balance is 100 SGD\",\"endpoint\":\"TechStudio\",\"client\" :\"ANZ\",\"RequestDateTime\":"+'"'+formattedDate+'"'+"}}}";
        	 HttpHeaders headers = new HttpHeaders();
        	headers.setContentType(MediaType.APPLICATION_JSON);
        	RestTemplate restTemplate = new RestTemplate();
    	    String url = "http://localhost:8080/WireConnectNotification/CCPushNotification";
    	    HttpEntity<String> requestEntity = null;
            requestEntity=new HttpEntity<String>(input, headers);
            //URI uri = restTemplate.postForLocation(url, requestEntity);
            
           restTemplate.postForEntity(url, requestEntity, null);
            
           //System.out.println(uri.getPath());
            
          
        }

   
    public static void main(String args[]) throws InterruptedException {
    	CoreCardRestClient util=null;
    	util = new CoreCardRestClient();
    	long start = System.currentTimeMillis();
    	 long count = 1;
    	for (int i = 1; i <=10; i++) {
    		
        	util.sendSMSGlobal(); //jppl
    	   // util.sendMach();//lml
    	   //util.sendTechStudio();
        
        
		}
    	long diff = System.currentTimeMillis() - start;
    	
    	 System.out.println(String.format("c %d in %.2f seconds", count, (1.0*diff/1000.0)));
    }    
}
